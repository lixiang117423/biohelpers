#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom dplyr %>%
#' @importFrom dplyr arrange
#' @importFrom dplyr left_join
#' @importFrom dplyr mutate
#' @importFrom dplyr select
#' @importFrom factoextra get_eigenvalue
#' @importFrom FactoMineR PCA
#' @importFrom ggplot2 aes
#' @importFrom ggplot2 geom_hline
#' @importFrom ggplot2 geom_point
#' @importFrom ggplot2 geom_vline
#' @importFrom ggplot2 ggplot
#' @importFrom ggplot2 labs
#' @importFrom magrittr set_names
#' @importFrom stringr str_replace
#' @importFrom tibble rownames_to_column
#' @importFrom tidyr pivot_longer
#' @importFrom WGCNA corAndPvalue
## usethis namespace: end
NULL
